<?php
echo json_encode(['message' => 'pong']);
?>