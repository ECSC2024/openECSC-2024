worker_class = "eventlet"

bind         = "0.0.0.0:80"

keepalive    = 30
accesslog    = "-"
workers      = 12
user         = "web"