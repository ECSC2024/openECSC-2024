import os

def flag():
    return os.getenv('FLAG')