#if !defined(_SDE_DEFINES_H_)
#  define _SDE_DEFINES_H_

#  if !defined(SDE_KIND_EXTERNAL)
#    define SDE_KIND_EXTERNAL
#  endif
#  if !defined(SDE_APX)
#    define SDE_APX
#  endif
#  if !defined(SDE_EXTERNAL)
#    define SDE_EXTERNAL
#  endif
#  if !defined(SDE_INIT)
#    define SDE_INIT
#  endif
#  if !defined(SDE_KIND)
#    define SDE_KIND "external"
#  endif
#  if !defined(SDE_REVISION)
#    define SDE_REVISION "0"
#  endif
#  if !defined(SDE_VERSION)
#    define SDE_VERSION "9.33.0"
#  endif
#endif
